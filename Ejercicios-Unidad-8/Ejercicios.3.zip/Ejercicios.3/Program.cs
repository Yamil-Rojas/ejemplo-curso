﻿namespace Ejercicios._3;

class Program
{
    static void Main(string[] args)
    {
     //Hacer una función llamada “primo” que reciba un número entero y devuelva 1 si el número es primo o cero si no lo es. 
     //Hacer un programa para ingresar números. El lote corta cuando se ingresa un número cero. 
     //Informar el promedio teniendo en cuenta sólo los números primos.

    int n1, contadorPrimos = 0, acumuladorPrimos = 0, promedio;

    Console.WriteLine("Ingrese un número");
    n1 = int.Parse(Console.ReadLine());

    while (n1 != 0)
    {
        Console.WriteLine("Ingrese un número");
        n1 = int.Parse(Console.ReadLine());  
        contadorPrimos = primo(n1);
        contadorPrimos++;
        acumuladorPrimos+= n1;

    }
    promedio = acumuladorPrimos / contadorPrimos;
    Console.WriteLine("El promedio es: " + promedio);
    }

    static int primo (int a){
    int r;    
    if (a % 1 == 0 && a % a == 0){
        r = 1;
    } else r = 0;
    return r;
}
}